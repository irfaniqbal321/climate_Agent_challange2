import 'package:flutter/material.dart';
import 'find_hospital_screen.dart';
import 'check_medicine_screen.dart';
import 'prescription_scanner_screen.dart';
import 'drug_interaction_screen.dart';
import 'chat_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sehat Saathi'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Welcome Header
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  const Icon(Icons.health_and_safety, size: 64, color: Color(0xFF006600)),
                  const SizedBox(height: 16),
                  Text(
                    'Welcome to Sehat Saathi',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: Theme.of(context).primaryColor,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'آپ کا صحت کا ساتھی',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          fontSize: 18,
                        ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Main Primary Buttons
            _buildPrimaryButton(
              context,
              title: 'Find Hospital',
              urduTitle: 'ہسپتال تلاش کریں',
              icon: Icons.local_hospital,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FindHospitalScreen())),
            ),
            const SizedBox(height: 16),
            _buildPrimaryButton(
              context,
              title: 'Check Medicine',
              urduTitle: 'ادویات چیک کریں',
              icon: Icons.medication,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CheckMedicineScreen())),
            ),
            const SizedBox(height: 32),

            // Secondary Options Grid
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              children: [
                _buildSecondaryCard(
                  context,
                  title: 'Scanner',
                  icon: Icons.document_scanner,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrescriptionScannerScreen())),
                ),
                _buildSecondaryCard(
                  context,
                  title: 'Interactions',
                  icon: Icons.warning_amber_rounded,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DrugInteractionScreen())),
                ),
                _buildSecondaryCard(
                  context,
                  title: 'Ask Saathi',
                  icon: Icons.chat_bubble_outline,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen())),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildPrimaryButton(BuildContext context, {required String title, required String urduTitle, required IconData icon, required VoidCallback onTap}) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 20),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 28),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 18)),
              Text(urduTitle, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.normal)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSecondaryCard(BuildContext context, {required String title, required IconData icon, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      child: Card(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: Theme.of(context).colorScheme.secondary),
            const SizedBox(height: 12),
            Text(
              title,
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ],
        ),
      ),
    );
  }
}
